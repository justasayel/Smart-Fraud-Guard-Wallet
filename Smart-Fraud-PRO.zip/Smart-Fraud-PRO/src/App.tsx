import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { BalanceCard } from './components/BalanceCard';
import { QuickActions } from './components/QuickActions';
import { TransactionList, Transaction } from './components/TransactionList';
import { FraudAlert } from './components/FraudAlert';
import { WalletPage } from './components/WalletPage';
import { AnalysisPage } from './components/AnalysisPage';
import { LoansPage } from './components/LoansPage';
import { ProfilePage } from './components/ProfilePage';
import { AdminDashboard } from './components/AdminDashboard';
import { analyzeTransaction, TransactionData } from './services/fraudEngine';
import { useBehavioralBiometrics } from './services/behavioralBiometrics';
import { Shield, X, AlertCircle, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: '1', type: 'out', category: 'Food', amount: 12.50, merchant: 'Starbucks', timestamp: 'Today, 10:24 AM' },
  { id: '2', type: 'out', category: 'Shopping', amount: 85.00, merchant: 'Amazon', timestamp: 'Yesterday, 4:15 PM' },
  { id: '3', type: 'in', category: 'Income', amount: 3200.00, merchant: 'Monthly Salary', timestamp: 'Oct 1, 2023' },
  { id: '4', type: 'out', category: 'Transport', amount: 24.00, merchant: 'Uber', timestamp: 'Sep 28, 2023', riskScore: 55 },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  
  const handleTabChange = (tab: string) => {
    console.log('Changing tab to:', tab);
    setActiveTab(tab);
  };

  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferAmount, setTransferAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [transactions, setTransactions] = useState(INITIAL_TRANSACTIONS);
  const [balance, setBalance] = useState(12450.00);
  
  const { profile, verifyIdentity } = useBehavioralBiometrics();

  const handleTransfer = async () => {
    setIsAnalyzing(true);
    
    const txData: TransactionData = {
      amount: parseFloat(transferAmount),
      location: 'New York, USA', // Simulated
      time: new Date().toLocaleTimeString(),
      recipient: recipient,
      deviceFingerprint: 'iPhone-14-Pro-XYZ',
    };

    const result = await analyzeTransaction(txData, profile);
    setAnalysisResult(result);
    setIsAnalyzing(false);

    if (result.decision === 'APPROVE') {
      completeTransaction(txData);
    }
  };

  const completeTransaction = (txData: TransactionData) => {
    const newTx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'out',
      category: 'Transfer',
      amount: txData.amount,
      merchant: txData.recipient,
      timestamp: 'Just now',
    };
    setTransactions([newTx, ...transactions]);
    setBalance(prev => prev - txData.amount);
    setIsTransferModalOpen(false);
    setAnalysisResult(null);
    setTransferAmount('');
    setRecipient('');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center text-accent">
                  <Shield size={20} />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Welcome back,</p>
                  <p className="font-bold">Asayel Alghamdi</p>
                </div>
              </div>
              <button 
                onClick={() => setActiveTab('admin')}
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400"
              >
                <AlertCircle size={20} />
              </button>
            </div>

            <BalanceCard 
              balance={balance} 
              available={balance - 2000} 
              riskScore={12} 
              creditHealth={94} 
            />

            <QuickActions onAction={(id) => {
              if (id === 'transfer') setIsTransferModalOpen(true);
              else if (id === 'loan') setActiveTab('loans');
              else if (id === 'convert') setActiveTab('analysis');
              else alert(`Action ${id} triggered`);
            }} />

            <div className="grid grid-cols-1 gap-4">
              <button 
                onClick={() => setIsTransferModalOpen(true)}
                className="w-full py-4 rounded-2xl bg-accent text-black font-bold shadow-lg shadow-accent/20 active:scale-95 transition-all cursor-pointer"
              >
                New Transfer
              </button>
            </div>

            <FraudAlert 
              type="warning"
              message="A login attempt was detected from an unrecognized device in London, UK."
              location="London, UK"
              onVerify={() => alert('Identity Verified')}
            />

            <TransactionList transactions={transactions} />
          </div>
        );
      case 'wallet':
        return <WalletPage />;
      case 'analysis':
        return <AnalysisPage />;
      case 'loans':
        return <LoansPage />;
      case 'profile':
        return <ProfilePage />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return null;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={handleTabChange}>
      {renderContent()}

      {/* Transfer Modal */}
      <AnimatePresence>
        {isTransferModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsTransferModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-[#0B0F19] rounded-t-[32px] sm:rounded-[32px] p-8 border border-white/10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-xl font-bold">Secure Transfer</h3>
                <button onClick={() => setIsTransferModalOpen(false)} className="text-gray-500">
                  <X size={24} />
                </button>
              </div>

              {!analysisResult ? (
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 block">Recipient</label>
                    <input 
                      type="text" 
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      placeholder="Name or Account Number"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 outline-none focus:border-accent transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 block">Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">$</span>
                      <input 
                        type="number" 
                        value={transferAmount}
                        onChange={(e) => setTransferAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl pl-8 pr-4 py-4 text-2xl font-bold outline-none focus:border-accent transition-colors"
                      />
                    </div>
                  </div>

                  <button
                    disabled={!transferAmount || !recipient || isAnalyzing}
                    onClick={handleTransfer}
                    className="w-full py-4 rounded-2xl bg-accent text-black font-bold flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                        AI Analyzing Risk...
                      </>
                    ) : 'Review & Send'}
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className={`p-6 rounded-3xl border ${
                    analysisResult.decision === 'APPROVE' ? 'bg-accent/10 border-accent/20' : 
                    analysisResult.decision === 'ALERT' ? 'bg-warning/10 border-warning/20' : 
                    'bg-fraud/10 border-fraud/20'
                  }`}>
                    <div className="flex items-center gap-3 mb-4">
                      {analysisResult.decision === 'APPROVE' ? (
                        <CheckCircle2 className="text-accent" size={24} />
                      ) : (
                        <AlertCircle className={analysisResult.decision === 'ALERT' ? 'text-warning' : 'text-fraud'} size={24} />
                      )}
                      <h4 className="font-bold">AI Risk Assessment</h4>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-400">Risk Score</span>
                        <span className={`font-bold ${analysisResult.riskScore < 40 ? 'text-accent' : 'text-fraud'}`}>
                          {analysisResult.riskScore}/100
                        </span>
                      </div>
                      <p className="text-sm text-gray-200">{analysisResult.reason}</p>
                      <div className="pt-3 border-t border-white/5">
                        <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Digital Twin Analysis</p>
                        <p className="text-xs text-gray-400 italic">"{analysisResult.digitalTwinComparison}"</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button 
                      onClick={() => setAnalysisResult(null)}
                      className="flex-1 py-4 rounded-2xl bg-white/5 font-bold"
                    >
                      Cancel
                    </button>
                    {analysisResult.decision !== 'BLOCK' && (
                      <button 
                        onClick={() => completeTransaction({
                          amount: parseFloat(transferAmount),
                          recipient,
                          location: 'New York',
                          time: '',
                          deviceFingerprint: ''
                        })}
                        className={`flex-1 py-4 rounded-2xl font-bold ${
                          analysisResult.decision === 'APPROVE' ? 'bg-accent text-black' : 'bg-warning text-black'
                        }`}
                      >
                        {analysisResult.decision === 'APPROVE' ? 'Confirm' : 'Verify & Send'}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
