import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Default config placeholder
const defaultConfig = {
  apiKey: "placeholder",
  authDomain: "placeholder",
  projectId: "placeholder",
  storageBucket: "placeholder",
  messagingSenderId: "placeholder",
  appId: "placeholder"
};

let firebaseConfig = defaultConfig;

try {
  // In AI Studio, this file is injected after setup
  const config = require('./firebase-applet-config.json');
  firebaseConfig = config;
} catch (e) {
  console.warn("Firebase config not found. Please complete setup.");
}

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;
