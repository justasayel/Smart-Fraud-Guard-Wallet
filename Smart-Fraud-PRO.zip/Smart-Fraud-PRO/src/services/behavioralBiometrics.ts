import { useState, useEffect, useCallback } from 'react';

export interface BehavioralProfile {
  avgTypingSpeed: number;
  avgSwipeSpeed: number;
  touchPressure: number;
  gesturePatterns: string[];
  navigationRhythm: number;
}

export const useBehavioralBiometrics = () => {
  const [profile, setProfile] = useState<BehavioralProfile>({
    avgTypingSpeed: 0,
    avgSwipeSpeed: 0,
    touchPressure: 0,
    gesturePatterns: [],
    navigationRhythm: 0,
  });

  const [lastInteraction, setLastInteraction] = useState<number>(Date.now());
  const [typingStarts, setTypingStarts] = useState<number[]>([]);

  const trackInteraction = useCallback(() => {
    const now = Date.now();
    const interval = now - lastInteraction;
    setLastInteraction(now);
    
    setProfile(prev => ({
      ...prev,
      navigationRhythm: (prev.navigationRhythm + interval) / 2
    }));
  }, [lastInteraction]);

  useEffect(() => {
    const handleMouseMove = () => trackInteraction();
    const handleKeyDown = () => {
      const now = Date.now();
      setTypingStarts(prev => [...prev.slice(-10), now]);
      
      if (typingStarts.length > 1) {
        const speed = now - typingStarts[typingStarts.length - 1];
        setProfile(prev => ({
          ...prev,
          avgTypingSpeed: (prev.avgTypingSpeed + speed) / 2
        }));
      }
      trackInteraction();
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('click', trackInteraction);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('click', trackInteraction);
    };
  }, [trackInteraction, typingStarts]);

  const verifyIdentity = (currentBehavior: BehavioralProfile): number => {
    // Simplified verification logic
    // Returns a risk score (0-100) based on deviation from baseline
    let deviation = 0;
    
    // In a real app, this would compare against a stored baseline in Firestore
    // For this demo, we'll simulate a low risk if behavior is "normal"
    return Math.floor(Math.random() * 20); // Simulating low risk for now
  };

  return { profile, verifyIdentity };
};
