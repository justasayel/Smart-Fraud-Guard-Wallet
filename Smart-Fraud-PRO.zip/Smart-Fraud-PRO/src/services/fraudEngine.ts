import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface TransactionData {
  amount: number;
  location: string;
  time: string;
  recipient: string;
  deviceFingerprint: string;
}

export interface FraudAnalysisResult {
  riskScore: number;
  decision: 'APPROVE' | 'ALERT' | 'BLOCK';
  reason: string;
  digitalTwinComparison: string;
}

export const analyzeTransaction = async (
  transaction: TransactionData,
  userProfile: any
): Promise<FraudAnalysisResult> => {
  try {
    const prompt = `
      Analyze this fintech transaction for potential fraud.
      
      User Digital Twin Profile:
      - Typical Amount Range: $10 - $500
      - Common Locations: New York, San Francisco
      - Usual Times: 8 AM - 10 PM
      - Frequent Recipients: Utilities, Grocery, Coffee Shops
      
      Current Transaction:
      - Amount: $${transaction.amount}
      - Location: ${transaction.location}
      - Time: ${transaction.time}
      - Recipient: ${transaction.recipient}
      - Device: ${transaction.deviceFingerprint}
      
      Return a JSON object with:
      - riskScore (0-100)
      - decision (APPROVE if score < 40, ALERT if 40-70, BLOCK if > 70)
      - reason (brief explanation)
      - digitalTwinComparison (how it deviates from the user's normal behavior)
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || '{}');
    return {
      riskScore: result.riskScore || 0,
      decision: result.decision || 'APPROVE',
      reason: result.reason || 'No significant risk detected.',
      digitalTwinComparison: result.digitalTwinComparison || 'Consistent with behavioral profile.',
    };
  } catch (error) {
    console.error('Fraud Analysis Error:', error);
    return {
      riskScore: 10,
      decision: 'APPROVE',
      reason: 'Analysis unavailable, falling back to baseline security.',
      digitalTwinComparison: 'N/A',
    };
  }
};
