import React from 'react';
import { Shield, TrendingUp } from 'lucide-react';

interface BalanceCardProps {
  balance: number;
  available: number;
  riskScore: number;
  creditHealth: number;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({ balance, available, riskScore, creditHealth }) => {
  return (
    <div className="navy-gradient rounded-3xl p-6 shadow-2xl relative overflow-hidden border border-white/5">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 blur-3xl rounded-full -mr-16 -mt-16" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-500/10 blur-2xl rounded-full -ml-12 -mb-12" />

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-gray-400 text-sm font-medium mb-1">Total Balance</p>
            <h2 className="text-4xl font-bold tracking-tight">
              ${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </h2>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-2 rounded-xl border border-white/10">
            <Shield className={riskScore < 40 ? 'text-accent' : riskScore < 70 ? 'text-warning' : 'text-fraud'} size={20} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <p className="text-gray-500 text-[10px] uppercase tracking-wider mb-1">Available Funds</p>
            <p className="text-lg font-semibold">${available.toLocaleString()}</p>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <p className="text-gray-500 text-[10px] uppercase tracking-wider mb-1">Credit Health</p>
            <div className="flex items-center gap-2">
              <p className="text-lg font-semibold">{creditHealth}%</p>
              <TrendingUp size={14} className="text-accent" />
            </div>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <span className="text-xs text-gray-400">AI Fraud Guard Active</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400">Risk Score:</span>
            <span className={`text-xs font-bold ${riskScore < 40 ? 'text-accent' : riskScore < 70 ? 'text-warning' : 'text-fraud'}`}>
              {riskScore}/100
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
