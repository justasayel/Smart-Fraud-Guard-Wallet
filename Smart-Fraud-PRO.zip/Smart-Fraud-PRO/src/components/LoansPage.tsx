import React from 'react';
import { Landmark, Calendar, ArrowRight } from 'lucide-react';

interface LoanCardProps {
  bank: string;
  amount: number;
  remaining: number;
  installment: number;
  progress: number;
  dueDate: string;
}

export const LoanCard: React.FC<LoanCardProps> = ({ bank, amount, remaining, installment, progress, dueDate }) => {
  return (
    <div className="glass-card p-5 space-y-4">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-400">
            <Landmark size={20} />
          </div>
          <div>
            <h4 className="font-bold text-sm">{bank}</h4>
            <p className="text-[10px] text-gray-500 uppercase tracking-wider">Personal Loan</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-400">Monthly</p>
          <p className="font-bold text-sm text-accent">${installment.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-gray-500">Repayment Progress</span>
          <span className="font-bold">{progress}%</span>
        </div>
        <div className="h-2 bg-white/5 rounded-full overflow-hidden">
          <div 
            className="h-full bg-accent rounded-full transition-all duration-1000" 
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-gray-500">
          <span>Paid: ${(amount - remaining).toLocaleString()}</span>
          <span>Total: ${amount.toLocaleString()}</span>
        </div>
      </div>
      
      <div className="pt-4 border-t border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <Calendar size={14} />
          <span>Next: {dueDate}</span>
        </div>
        <button 
          type="button"
          onClick={() => alert('Processing payment...')}
          className="text-accent text-xs font-bold flex items-center gap-1 cursor-pointer hover:underline"
        >
          Pay Now <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
};

export const LoansPage: React.FC = () => {
  const loans: LoanCardProps[] = [
    { bank: 'HSBC Global', amount: 25000, remaining: 12400, installment: 850, progress: 52, dueDate: 'Oct 15, 2023' },
    { bank: 'Goldman Sachs', amount: 15000, remaining: 14200, installment: 420, progress: 5, dueDate: 'Oct 22, 2023' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Loan Management</h2>
        <button 
          type="button"
          onClick={() => alert('Redirecting to loan application...')}
          className="bg-accent text-black px-4 py-2 rounded-xl text-xs font-bold cursor-pointer active:scale-95 transition-all"
        >
          Apply New
        </button>
      </div>

      <div className="space-y-4">
        {loans.map((loan, i) => (
          <LoanCard key={i} {...loan} />
        ))}
      </div>

      <div className="bg-warning/10 border border-warning/20 rounded-2xl p-4 flex items-start gap-3">
        <div className="p-2 bg-warning/20 text-warning rounded-lg">
          <Calendar size={20} />
        </div>
        <div>
          <h4 className="text-sm font-bold text-warning">Upcoming Payment</h4>
          <p className="text-xs text-gray-300 mt-1">
            Your HSBC Global installment of $850 is due in 3 days. Ensure your balance is sufficient.
          </p>
        </div>
      </div>
    </div>
  );
};
