import React from 'react';
import { User, Shield, Smartphone, Bell, Settings, ChevronRight, LogOut, Fingerprint, Key } from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const sections = [
    {
      title: 'Security Settings',
      items: [
        { icon: Fingerprint, label: 'Biometric Login', value: 'Enabled', color: 'text-accent' },
        { icon: Key, label: 'Two-Factor Auth', value: 'Active', color: 'text-accent' },
        { icon: Smartphone, label: 'Trusted Devices', value: '2 Connected', color: 'text-gray-400' },
      ]
    },
    {
      title: 'App Preferences',
      items: [
        { icon: Bell, label: 'Fraud Notifications', value: 'Instant', color: 'text-gray-400' },
        { icon: Shield, label: 'Privacy Mode', value: 'Off', color: 'text-gray-400' },
        { icon: Settings, label: 'System Settings', value: '', color: 'text-gray-400' },
      ]
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col items-center text-center pt-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-accent to-blue-500 p-1">
            <div className="w-full h-full rounded-full bg-[#0B0F19] flex items-center justify-center overflow-hidden">
              <User size={48} className="text-gray-600" />
            </div>
          </div>
          <div className="absolute bottom-0 right-0 w-6 h-6 bg-accent rounded-full border-4 border-[#0B0F19] flex items-center justify-center">
            <Shield size={10} className="text-black" />
          </div>
        </div>
        <h3 className="text-xl font-bold mt-4">Asayel Alghamdi</h3>
        <p className="text-xs text-gray-500">Premium Member • Joined 2021</p>
      </div>

      <div className="space-y-6">
        {sections.map((section, i) => (
          <div key={i} className="space-y-3">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest px-1">
              {section.title}
            </p>
            <div className="glass-card overflow-hidden">
              {section.items.map((item, j) => {
                const Icon = item.icon;
                return (
                  <button
                    key={j}
                    className={`w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors ${j !== section.items.length - 1 ? 'border-bottom border-white/5' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-gray-400">
                        <Icon size={18} />
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold ${item.color}`}>{item.value}</span>
                      <ChevronRight size={16} className="text-gray-600" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <button className="w-full py-4 rounded-2xl bg-fraud/10 text-fraud font-bold flex items-center justify-center gap-2 active:scale-95 transition-all">
        <LogOut size={18} /> Sign Out
      </button>
      
      <p className="text-center text-[10px] text-gray-600 pb-8">
        Smart Fraud Guard Wallet v2.4.0<br />
        Securely encrypted with AES-256
      </p>
    </div>
  );
};
