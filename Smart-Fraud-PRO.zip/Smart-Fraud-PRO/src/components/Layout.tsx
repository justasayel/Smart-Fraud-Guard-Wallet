import React, { useState, useEffect } from 'react';
import { BottomNav } from './BottomNav';
import { motion, AnimatePresence } from 'motion/react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  return (
    <div className="min-h-screen bg-[#0B0F19] pb-24">
      <AnimatePresence mode="wait">
        <motion.main
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="px-4 pt-6 max-w-lg mx-auto"
        >
          {children}
        </motion.main>
      </AnimatePresence>
      <BottomNav activeTab={activeTab} onTabChange={onTabChange} />
    </div>
  );
};
