import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { Brain, TrendingDown, AlertTriangle, Zap } from 'lucide-react';

const spendingData = [
  { name: 'Mon', amount: 45 },
  { name: 'Tue', amount: 52 },
  { name: 'Wed', amount: 38 },
  { name: 'Thu', amount: 65 },
  { name: 'Fri', amount: 48 },
  { name: 'Sat', amount: 85 },
  { name: 'Sun', amount: 32 },
];

const categoryData = [
  { name: 'Food', value: 35, color: '#2ED47A' },
  { name: 'Rent', value: 45, color: '#0A1F44' },
  { name: 'Travel', value: 15, color: '#F59E0B' },
  { name: 'Other', value: 5, color: '#E5E7EB' },
];

export const AnalysisPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI Intelligence</h2>
        <div className="bg-accent/10 text-accent px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
          <Zap size={10} /> Real-time
        </div>
      </div>

      {/* AI Insights Card */}
      <div className="bg-gradient-to-br from-indigo-600/20 to-blue-600/20 rounded-3xl p-6 border border-blue-500/20">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-500/20 rounded-xl text-blue-400">
            <Brain size={20} />
          </div>
          <h3 className="font-bold">Financial Digital Twin</h3>
        </div>
        <p className="text-sm text-gray-300 leading-relaxed">
          "Your spending on <span className="text-white font-bold">Dining Out</span> is 22% higher than your typical behavioral profile. Consider adjusting your budget for the next week."
        </p>
        <div className="mt-4 flex items-center gap-2 text-xs font-medium text-blue-400">
          <span>Accuracy: 98.4%</span>
          <div className="w-1 h-1 rounded-full bg-blue-400" />
          <span>Model: Behavioral-v4</span>
        </div>
      </div>

      {/* Spending Chart */}
      <div className="glass-card p-6">
        <div className="flex justify-between items-center mb-6">
          <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Spending Analytics</h4>
          <select className="bg-transparent text-xs font-bold text-accent outline-none">
            <option>This Week</option>
            <option>Last Week</option>
          </select>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={spendingData}>
              <defs>
                <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2ED47A" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#2ED47A" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#6B7280', fontSize: 10 }} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0B0F19', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                itemStyle={{ color: '#2ED47A' }}
              />
              <Area 
                type="monotone" 
                dataKey="amount" 
                stroke="#2ED47A" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorAmount)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Risk Prediction */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown size={16} className="text-accent" />
            <span className="text-[10px] font-bold text-gray-500 uppercase">Risk Level</span>
          </div>
          <p className="text-2xl font-bold">Low</p>
          <p className="text-[10px] text-gray-400 mt-1">Stable financial health</p>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle size={16} className="text-warning" />
            <span className="text-[10px] font-bold text-gray-500 uppercase">Anomalies</span>
          </div>
          <p className="text-2xl font-bold">2</p>
          <p className="text-[10px] text-gray-400 mt-1">Detected this month</p>
        </div>
      </div>
    </div>
  );
};
