import React from 'react';
import { CreditCard as CardIcon, Plus, Landmark } from 'lucide-react';

interface CardProps {
  type: 'visa' | 'mastercard';
  number: string;
  expiry: string;
  holder: string;
  color: string;
}

export const CreditCard: React.FC<CardProps> = ({ type, number, expiry, holder, color }) => {
  return (
    <div className={`w-full aspect-[1.6/1] rounded-2xl p-6 relative overflow-hidden shadow-xl ${color}`}>
      {/* Card chip */}
      <div className="w-10 h-8 bg-yellow-400/80 rounded-md mb-8 relative">
        <div className="absolute inset-0 border border-black/10 rounded-md flex flex-col justify-around px-1">
          <div className="h-[1px] bg-black/10 w-full" />
          <div className="h-[1px] bg-black/10 w-full" />
        </div>
      </div>
      
      <div className="space-y-4">
        <p className="text-xl font-medium tracking-[0.2em] text-white/90">
          •••• •••• •••• {number.slice(-4)}
        </p>
        
        <div className="flex justify-between items-end">
          <div>
            <p className="text-[10px] text-white/60 uppercase tracking-wider">Card Holder</p>
            <p className="text-sm font-medium uppercase">{holder}</p>
          </div>
          <div>
            <p className="text-[10px] text-white/60 uppercase tracking-wider">Expires</p>
            <p className="text-sm font-medium">{expiry}</p>
          </div>
          <div className="text-right">
            <p className="text-lg font-bold italic text-white/90">{type === 'visa' ? 'VISA' : 'Mastercard'}</p>
          </div>
        </div>
      </div>
      
      {/* Decorative circles */}
      <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
    </div>
  );
};

export const WalletPage: React.FC = () => {
  const cards: CardProps[] = [
    { type: 'visa', number: '4532 1234 5678 9012', expiry: '12/26', holder: 'ALEX JOHNSON', color: 'bg-gradient-to-br from-blue-600 to-indigo-900' },
    { type: 'mastercard', number: '5412 9876 5432 1098', expiry: '08/25', holder: 'ALEX JOHNSON', color: 'bg-gradient-to-br from-gray-800 to-black' },
  ];

  const accounts = [
    { id: '1', name: 'Main Savings', bank: 'Chase Bank', balance: 12450.00, number: '**** 4421' },
    { id: '2', name: 'Investment Account', bank: 'Vanguard', balance: 45200.50, number: '**** 8832' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">My Wallet</h2>
        <button className="w-10 h-10 rounded-full bg-accent/10 text-accent flex items-center justify-center">
          <Plus size={20} />
        </button>
      </div>

      <div className="space-y-4">
        <p className="text-sm font-medium text-gray-500 uppercase tracking-widest">Your Cards</p>
        <div className="flex gap-4 overflow-x-auto pb-4 snap-x no-scrollbar">
          {cards.map((card, i) => (
            <div key={i} className="min-w-[85%] snap-center">
              <CreditCard {...card} />
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <p className="text-sm font-medium text-gray-500 uppercase tracking-widest">Bank Accounts</p>
        <div className="space-y-3">
          {accounts.map((acc) => (
            <div key={acc.id} className="glass-card p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-gray-400">
                  <Landmark size={20} />
                </div>
                <div>
                  <p className="font-medium text-sm">{acc.name}</p>
                  <p className="text-xs text-gray-500">{acc.bank} • {acc.number}</p>
                </div>
              </div>
              <p className="font-bold text-sm">${acc.balance.toLocaleString()}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
