import React from 'react';
import { AlertCircle, ShieldAlert, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface FraudAlertProps {
  type: 'warning' | 'critical';
  message: string;
  location?: string;
  amount?: number;
  onVerify: () => void;
}

export const FraudAlert: React.FC<FraudAlertProps> = ({ type, message, location, amount, onVerify }) => {
  const isCritical = type === 'critical';
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-2xl p-4 mb-6 border ${isCritical ? 'bg-fraud/10 border-fraud/20' : 'bg-warning/10 border-warning/20'}`}
    >
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg ${isCritical ? 'bg-fraud/20 text-fraud' : 'bg-warning/20 text-warning'}`}>
          <ShieldAlert size={20} />
        </div>
        <div className="flex-1">
          <h4 className={`text-sm font-bold ${isCritical ? 'text-fraud' : 'text-warning'}`}>
            {isCritical ? 'Critical Fraud Alert' : 'Suspicious Activity'}
          </h4>
          <p className="text-xs text-gray-300 mt-1 leading-relaxed">
            {message}
          </p>
          
          {(location || amount) && (
            <div className="mt-3 flex gap-4">
              {amount && (
                <div>
                  <p className="text-[10px] text-gray-500 uppercase">Amount</p>
                  <p className="text-xs font-bold">${amount.toFixed(2)}</p>
                </div>
              )}
              {location && (
                <div>
                  <p className="text-[10px] text-gray-500 uppercase">Location</p>
                  <p className="text-xs font-bold">{location}</p>
                </div>
              )}
            </div>
          )}
          
          <button
            onClick={onVerify}
            className={`mt-4 w-full py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 ${
              isCritical ? 'bg-fraud text-white' : 'bg-warning text-black'
            }`}
          >
            Verify Transaction <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </motion.div>
  );
};
