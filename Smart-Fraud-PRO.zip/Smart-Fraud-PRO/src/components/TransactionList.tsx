import React from 'react';
import { ArrowUpRight, ArrowDownLeft, ShoppingBag, Coffee, Car, ShieldAlert } from 'lucide-react';

export interface Transaction {
  id: string;
  type: 'in' | 'out';
  category: string;
  amount: number;
  merchant: string;
  timestamp: string;
  riskScore?: number;
}

const categoryIcons: Record<string, any> = {
  Shopping: ShoppingBag,
  Food: Coffee,
  Transport: Car,
  Transfer: ArrowUpRight,
  Income: ArrowDownLeft,
};

export const TransactionList: React.FC<{ transactions: Transaction[] }> = ({ transactions }) => {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-1">
        <h3 className="text-lg font-semibold">Recent Activity</h3>
        <button className="text-accent text-sm font-medium">See All</button>
      </div>
      
      <div className="space-y-3">
        {transactions.map((tx) => {
          const Icon = categoryIcons[tx.category] || ShoppingBag;
          const isSuspicious = tx.riskScore && tx.riskScore > 40;
          
          return (
            <div key={tx.id} className="glass-card p-4 flex items-center justify-between group hover:bg-white/[0.08] transition-colors cursor-pointer">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isSuspicious ? 'bg-fraud/10 text-fraud' : 'bg-white/5 text-gray-400'}`}>
                  <Icon size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{tx.merchant}</p>
                    {isSuspicious && <ShieldAlert size={14} className="text-fraud" />}
                  </div>
                  <p className="text-xs text-gray-500">{tx.category} • {tx.timestamp}</p>
                </div>
              </div>
              <div className="text-right">
                <p className={`font-bold text-sm ${tx.type === 'in' ? 'text-accent' : 'text-white'}`}>
                  {tx.type === 'in' ? '+' : '-'}${tx.amount.toFixed(2)}
                </p>
                {isSuspicious && (
                  <p className="text-[10px] font-bold text-fraud uppercase tracking-tighter">High Risk</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
