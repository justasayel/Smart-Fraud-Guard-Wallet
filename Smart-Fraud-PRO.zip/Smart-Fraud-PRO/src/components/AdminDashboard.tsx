import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { ShieldAlert, Users, Activity, Globe } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 400;
    const height = 300;

    const nodes = [
      { id: 'User A', group: 1 },
      { id: 'User B', group: 1 },
      { id: 'User C', group: 2 },
      { id: 'Device 1', group: 3 },
      { id: 'Device 2', group: 3 },
      { id: 'IP: 192.168.1.1', group: 4 },
      { id: 'Suspicious Node', group: 5 },
    ];

    const links = [
      { source: 'User A', target: 'Device 1' },
      { source: 'User B', target: 'Device 1' },
      { source: 'User C', target: 'Device 2' },
      { source: 'Device 1', target: 'IP: 192.168.1.1' },
      { source: 'Device 2', target: 'IP: 192.168.1.1' },
      { source: 'User A', target: 'Suspicious Node' },
      { source: 'Suspicious Node', target: 'IP: 192.168.1.1' },
    ];

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const simulation = d3.forceSimulation(nodes as any)
      .force('link', d3.forceLink(links).id((d: any) => d.id).distance(50))
      .force('charge', d3.forceManyBody().strength(-100))
      .force('center', d3.forceCenter(width / 2, height / 2));

    const link = svg.append('g')
      .selectAll('line')
      .data(links)
      .enter().append('line')
      .attr('stroke', 'rgba(255,255,255,0.1)')
      .attr('stroke-width', 1);

    const node = svg.append('g')
      .selectAll('circle')
      .data(nodes)
      .enter().append('circle')
      .attr('r', 6)
      .attr('fill', (d: any) => {
        if (d.group === 5) return '#EF4444';
        if (d.group === 3) return '#2ED47A';
        return '#0A1F44';
      })
      .attr('stroke', 'rgba(255,255,255,0.2)')
      .attr('stroke-width', 2);

    node.append('title').text((d: any) => d.id);

    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('cx', (d: any) => d.x)
        .attr('cy', (d: any) => d.y);
    });

    return () => simulation.stop();
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Security Analyst</h2>
        <div className="bg-fraud/10 text-fraud px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
          <Activity size={10} /> Live Monitoring
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <ShieldAlert size={16} className="text-fraud" />
            <span className="text-[10px] font-bold text-gray-500 uppercase">Active Alerts</span>
          </div>
          <p className="text-2xl font-bold">14</p>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users size={16} className="text-accent" />
            <span className="text-[10px] font-bold text-gray-500 uppercase">High Risk Users</span>
          </div>
          <p className="text-2xl font-bold">3</p>
        </div>
      </div>

      {/* Graph Analysis */}
      <div className="glass-card p-6">
        <div className="flex justify-between items-center mb-6">
          <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Fraud Graph Network</h4>
          <Globe size={16} className="text-gray-600" />
        </div>
        <div className="w-full h-[300px] bg-black/20 rounded-2xl overflow-hidden">
          <svg ref={svgRef} width="100%" height="100%" viewBox="0 0 400 300" />
        </div>
        <div className="mt-4 flex gap-4 justify-center">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-fraud" />
            <span className="text-[10px] text-gray-500">Suspicious</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <span className="text-[10px] text-gray-500">Device</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-primary" />
            <span className="text-[10px] text-gray-500">User</span>
          </div>
        </div>
      </div>

      {/* Recent Alerts Table */}
      <div className="space-y-3">
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest px-1">Critical Investigations</p>
        {[
          { id: 'AL-902', user: 'Mark S.', risk: 88, type: 'Velocity Attack' },
          { id: 'AL-901', user: 'Unknown', risk: 94, type: 'IP Mismatch' },
        ].map((item) => (
          <div key={item.id} className="glass-card p-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold">{item.type}</p>
              <p className="text-[10px] text-gray-500">ID: {item.id} • User: {item.user}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-fraud">{item.risk}% Risk</p>
              <button 
                type="button"
                onClick={() => alert(`Investigating ${item.id}`)}
                className="text-[10px] text-accent font-bold uppercase mt-1 cursor-pointer hover:underline"
              >
                Investigate
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
