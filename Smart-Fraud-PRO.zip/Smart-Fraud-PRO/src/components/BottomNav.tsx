import React from 'react';
import { Home, Wallet, BarChart3, Landmark, User } from 'lucide-react';
import { motion } from 'motion/react';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'wallet', icon: Wallet, label: 'Wallet' },
    { id: 'analysis', icon: BarChart3, label: 'Analysis' },
    { id: 'loans', icon: Landmark, label: 'Loans' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#0B0F19]/80 backdrop-blur-xl border-t border-white/5 px-6 py-3 safe-area-bottom z-50">
      <div className="flex justify-between items-center max-w-lg mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className="relative flex flex-col items-center gap-1 group cursor-pointer"
            >
              <div className={`p-2 rounded-xl transition-all duration-300 ${isActive ? 'bg-accent/20 text-accent' : 'text-gray-500 group-hover:text-gray-300'}`}>
                <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[10px] font-medium transition-all duration-300 ${isActive ? 'text-accent opacity-100' : 'text-gray-500 opacity-60'}`}>
                {tab.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute -top-1 w-1 h-1 bg-accent rounded-full"
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
