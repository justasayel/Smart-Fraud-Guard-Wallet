import React from 'react';
import { Send, CreditCard, ArrowDownLeft, Plus, Landmark, RefreshCw } from 'lucide-react';

interface QuickActionsProps {
  onAction?: (actionId: string) => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({ onAction }) => {
  const actions = [
    { id: 'transfer', icon: Send, label: 'Transfer', color: 'bg-blue-500/10 text-blue-400' },
    { id: 'pay', icon: CreditCard, label: 'Pay', color: 'bg-purple-500/10 text-purple-400' },
    { id: 'withdraw', icon: ArrowDownLeft, label: 'Withdraw', color: 'bg-orange-500/10 text-orange-400' },
    { id: 'request', icon: Plus, label: 'Request', color: 'bg-accent/10 text-accent' },
    { id: 'loan', icon: Landmark, label: 'Loan Pay', color: 'bg-emerald-500/10 text-emerald-400' },
    { id: 'convert', icon: RefreshCw, label: 'Exchange', color: 'bg-indigo-500/10 text-indigo-400' },
  ];

  return (
    <div className="grid grid-cols-3 gap-4 my-8">
      {actions.map((action) => {
        const Icon = action.icon;
        return (
          <button
            key={action.id}
            onClick={() => onAction?.(action.id)}
            className="flex flex-col items-center gap-2 group cursor-pointer"
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-active:scale-95 ${action.color}`}>
              <Icon size={24} />
            </div>
            <span className="text-xs font-medium text-gray-400 group-hover:text-white transition-colors">
              {action.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};
